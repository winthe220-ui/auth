from uuid import uuid4
from datetime import datetime, timedelta
from app.core.firebase import db
from app.utils.password import hash_password, verify_password
from app.core.config import REFRESH_TOKEN_EXPIRE_DAYS

def create_session(uid, role, refresh, ip, ua):
    sid = str(uuid4())
    db.collection("sessions").document(sid).set({
        "uid": uid,
        "role": role,
        "refresh": hash_password(refresh),
        "ip": ip,
        "ua": ua,
        "active": True,
        "created": datetime.utcnow(),
        "expires": datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    })
    return sid

def rotate_session(sid, old, new):
    ref = db.collection("sessions").document(sid)
    snap = ref.get()
    if not snap.exists:
        raise Exception("Session not found")

    data = snap.to_dict()
    if not data["active"] or not verify_password(old, data["refresh"]):
        ref.update({"active": False})
        raise Exception("Session invalid")

    ref.update({"refresh": hash_password(new)})
