from app.core.firebase import db
from app.utils.password import verify_password
from app.services.token_service import generate_tokens
from app.services.session_service import create_session
from app.services.rate_limit_services import rate_limit

def admin_login(email, password, request):
    ip = request.client.host
    if not rate_limit(f"admin:{ip}", 5, 60):
        raise Exception("Too many attempts")

    q = (
        db.collection("users")
        .where("email", "==", email)
        .where("role", "==", "admin")
        .limit(1)
        .stream()
    )

    admin = next(q, None)
    if not admin or not verify_password(password, admin.to_dict()["password"]):
        raise Exception("Invalid credentials")

    access, refresh = generate_tokens(admin.id, "admin")
    sid = create_session(admin.id, "admin", refresh, ip, request.headers.get("user-agent"))

    return access, refresh, sid
