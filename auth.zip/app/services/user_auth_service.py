from app.core.firebase import firebase_auth, db
from app.services.token_service import generate_tokens
from app.services.session_service import create_session
from app.services.rate_limit_services import rate_limit

def phone_login(id_token, request):
    ip = request.client.host
    if not rate_limit(f"phone:{ip}", 5, 60):
        raise Exception("Too many attempts")

    decoded = firebase_auth.verify_id_token(id_token)
    uid = decoded["uid"]

    db.collection("users").document(uid).set({
        "role": "user",
        "phone": decoded.get("phone_number")
    }, merge=True)

    access, refresh = generate_tokens(uid, "user")
    sid = create_session(uid, "user", refresh, ip, request.headers.get("user-agent"))

    return access, refresh, sid
