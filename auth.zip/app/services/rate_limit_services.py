from datetime import datetime, timedelta
from app.core.firebase import db

def rate_limit(key, limit, window):
    ref = db.collection("rate_limits").document(key)
    snap = ref.get()
    now = datetime.utcnow()

    if not snap.exists:
        ref.set({"count": 1, "reset": now + timedelta(seconds=window)})
        return True

    data = snap.to_dict()
    if now > data["reset"]:
        ref.set({"count": 1, "reset": now + timedelta(seconds=window)})
        return True

    if data["count"] >= limit:
        return False

    ref.update({"count": data["count"] + 1})
    return True
