from fastapi import APIRouter, Request
from app.services.admin_auth_service import admin_login
from app.utils.rbac import require_role

router = APIRouter(prefix="/admin")

@router.post("/login")
async def login(request: Request):
    body = await request.json()
    access, refresh, sid = admin_login(body["email"], body["password"], request)
    return {"access": access, "refresh": refresh, "session": sid}

@router.get("/dashboard")
def dashboard(user=require_role("admin")):
    return {"status": "admin ok"}
