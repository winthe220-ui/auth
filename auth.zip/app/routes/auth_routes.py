from fastapi import APIRouter, Request
from app.services.user_auth_service import phone_login
from app.services.session_service import rotate_session
from app.services.token_service import generate_tokens
from jose import jwt
from app.core.config import JWT_SECRET_KEY

router = APIRouter(prefix="/auth")

@router.post("/phone")
async def login(request: Request):
    body = await request.json()
    access, refresh, sid = phone_login(body["id_token"], request)
    return {"access": access, "refresh": refresh, "session": sid}

@router.post("/refresh")
async def refresh(request: Request):
    body = await request.json()
    payload = jwt.decode(body["refresh"], JWT_SECRET_KEY, algorithms=["HS256"])

    access, new_refresh = generate_tokens(payload["sub"], payload["role"])
    rotate_session(body["session"], body["refresh"], new_refresh)

    return {"access": access, "refresh": new_refresh}
