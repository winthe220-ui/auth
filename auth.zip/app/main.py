from fastapi import FastAPI
from app.routes.auth_routes import router as auth_router
from app.routes.admin_routes import router as admin_router

app = FastAPI()
app.include_router(auth_router)
app.include_router(admin_router)
