from fastapi import Depends, HTTPException
from app.core.dependencies import get_current_user

def require_role(role: str):
    def wrapper(user=Depends(get_current_user)):
        if user["role"] != role:
            raise HTTPException(403, "Forbidden")
        return user
    return wrapper
