from passlib.context import CryptContext

pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(p: str):
    return pwd.hash(p)

def verify_password(p: str, h: str):
    return pwd.verify(p, h)
