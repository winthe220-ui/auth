from typing import Optional
from datetime import datetime

class UserModel:
    def __init__(
        self,
        uid: str,
        phone: Optional[str],
        email: Optional[str],
        role: str = "user",
        is_active: bool = True,
        created_at: datetime = None
    ):
        self.uid = uid
        self.phone = phone
        self.email = email
        self.role = role
        self.is_active = is_active
        self.created_at = created_at or datetime.utcnow()
