import firebase_admin
from firebase_admin import credentials, firestore, auth
from app.core.config import FIREBASE_CREDENTIALS

cred = credentials.Certificate(FIREBASE_CREDENTIALS)

if not firebase_admin._apps:
    firebase_admin.initialize_app(cred)

db = firestore.client()
firebase_auth = auth
