from datetime import datetime, timedelta
from jose import jwt
from app.core.config import JWT_SECRET_KEY

def create_token(data: dict, expires: timedelta):
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + expires
    return jwt.encode(payload, JWT_SECRET_KEY, algorithm="HS256")
