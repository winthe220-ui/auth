from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer
from jose import jwt
from app.core.config import JWT_SECRET_KEY

security = HTTPBearer()

def get_current_user(token=Depends(security)):
    try:
        return jwt.decode(token.credentials, JWT_SECRET_KEY, algorithms=["HS256"])
    except:
        raise HTTPException(401, "Invalid token")
