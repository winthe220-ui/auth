from pydantic import BaseModel

class PhoneLogin(BaseModel):
    id_token: str  # Firebase phone OTP token

class AdminLogin(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
