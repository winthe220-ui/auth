from pydantic import BaseModel

class UserResponse(BaseModel):
    uid: str
    role: str
